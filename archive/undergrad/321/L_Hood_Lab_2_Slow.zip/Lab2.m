load('distance.mat')
load('time.mat')
distance = data(:,1) ;
distance_avg = mean(distance) ;

dev = distance - mean(distance) ;
var_top = 0 ;
for ii = 1:length(distance)
    var_top = dev(ii)^2 + var_top ;
end
var = var_top / ( length(distance) - 1 ) ;
sigma = sqrt(var) ; %standard deviation

alpha = sigma/(sqrt(length(distance))); %Standard error
distance_actual = 10 ; %cm
accuracy = 1-(distance_actual-distance_avg)/distance_actual ; 
precision = mean( abs(dev) ); 
[ h,p,stats ] = chi2gof( distance ) ;

figure
plot( t , distance )
xlabel('Time (s)')
ylabel('Distance (cm)')
title('Raw Data')



