%% Slow

load('distance.mat')
load('time.mat')
distance = data(:,1) ;

distance_avg = mean(distance) ;

dev = distance - mean(distance) ;
var_top = 0 ;
for ii = 1:length(distance)
    var_top = dev(ii)^2 + var_top ;
end
var = var_top / ( length(distance) - 1 ) ;
sigma = sqrt(var) ; %standard deviation

alpha = sigma/(sqrt(length(distance))); %Standard error
distance_actual = 10 ; %cm
accuracy = 1-(distance_actual-distance_avg)/distance_actual ; 
precision = mean( abs(dev) ); 
[ h,p,stats ] = chi2gof( distance ) ;

figure
plot( t , distance )
xlabel('Time (s)')
ylabel('Distance (cm)')
title('Raw Data')

%% Fast
load('data_100Hz.mat')
distance_100 = data_100(:,1) ;

distance_avg_100 = mean(distance_100) ;

dev_100 = distance_100 - mean(distance_100) ;
var_top_100 = 0 ;
for ii = 1:length(distance)
    var_top_100 = dev_100(ii)^2 + var_top_100 ;
end
var_100 = var_top_100 / ( length(distance_100) - 1 ) ;
sigma_100 = sqrt(var_100) ; %standard deviation

alpha_100 = sigma_100/(sqrt(length(distance_100))); %Standard error
distance_actual_100 = 10.5 ; %cm
accuracy_100 = 1-(distance_actual_100-distance_avg_100)/distance_actual ; 
precision_100 = mean( abs(dev_100) ); 
[ h,p,stats ] = chi2gof( distance_100 ) ;

figure
plot( t_100 , distance_100 )
xlabel('Time (s)')
ylabel('Distance (cm)')
title('Raw Data at 100 Hz')




