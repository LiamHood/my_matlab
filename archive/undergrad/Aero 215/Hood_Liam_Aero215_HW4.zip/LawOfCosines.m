a = 4 ;
b = 3 ;
ab = 60 ;

[ c ] = loc ( a,b,ab );

disp( 'Third Side' )
disp( c )
